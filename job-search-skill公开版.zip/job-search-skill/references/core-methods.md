# 使用入口

从[主题目录](index.md)查找条目，阅读观点卡及详细正文，并按[表达方式](voice-and-reasoning.md)给出建议。
