"""Search bundled viewpoint cards and knowledge entries; standard library only."""
import argparse
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def terms(text):
    chunks = re.findall(r'[a-z0-9]+|[\u4e00-\u9fff]+', text.lower())
    result = set(chunks)
    for c in chunks:
        if re.fullmatch(r'[\u4e00-\u9fff]+', c) and len(c) > 2:
            result.update(c[i:i+2] for i in range(len(c)-1))
    return result - {'我是','一个','怎么','如何','可以','没有','现在','需要','视频','顾问','顾问','观点','根据','帮我','什么','这种','那个','我的','自己','是不是'}

def expand(query):
    groups = [('中文','文科','汉语言'),('背调','背景调查'),('简历造假','编造实习','假经历'),('转行','转岗'),('找工作','求职'),('大学四年','大学规划'),('人工智能','AI')]
    for group in groups:
        if any(word.lower() in query.lower() for word in group):
            query+=' '+' '.join(group)
    return query

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('query', nargs='?', default='')
    ap.add_argument('--id')
    ap.add_argument('--source', action='store_true')
    ap.add_argument('--topic')
    ap.add_argument('--list-topics', action='store_true')
    ap.add_argument('--limit', type=int, default=5)
    args = ap.parse_args()
    rows = json.loads((ROOT/'references/views.json').read_text(encoding='utf-8'))
    if args.list_topics:
        for t in sorted({t for r in rows for t in r['themes']}):
            print(t)
        return
    if args.id:
        try: ident = int(args.id.upper().removeprefix('K'))
        except ValueError: ap.error('--id must be K001–K200 or 1–200')
        hits = [r for r in rows if r['id'] == ident]
        if not hits: ap.error('No such entry')
    elif args.topic:
        hits = [r for r in rows if any(args.topic in t for t in r['themes']+r['tags'])]
        for r in hits:
            print(f"K{r['id']:03} {r['heading']} | {', '.join(r['tags'])}")
        print(f'{len(hits)}条。用 --id 读取观点卡；加 --source 读取详细正文。')
        return
    else:
        if not args.query: ap.error('Provide a question, --id, --topic, or --list-topics')
        qs = terms(expand(args.query))
        corpus = json.loads((ROOT/'references/corpus.json').read_text(encoding='utf-8'))
        bodies = {r['id']:r['body'].lower() for r in corpus}
        ranked = []
        documents = {r['id']: (' '.join([r['heading']]+r['tags']+r['claims'])).lower() for r in rows}
        weights = {q:math.log(1+len(rows)/(1+sum(q in d for d in documents.values()))) for q in qs}
        for r in rows:
            title = r['heading'].lower()
            tags = ' '.join(r['tags']).lower()
            claims = ' '.join(r['claims']).lower()
            score = sum(weights[q]*(7*(q in title)+5*(q in tags)+2*(q in claims)+0.3*(q in bodies[r['id']])) for q in qs)
            if score: ranked.append((score,r))
        hits = [r for _,r in sorted(ranked,key=lambda x:(-x[0],x[1]['id']))[:max(1,min(args.limit,30))]]
        if not hits: print('未找到匹配；尝试岗位名、专业名或查看 --list-topics。')
    for r in hits:
        folder = 'entries' if args.source else 'cards'
        path = ROOT/'references'/folder/f"K{r['id']:03}.md"
        print(path.read_text(encoding='utf-8'))
        print('\n---\n')

if __name__ == '__main__':
    main()
